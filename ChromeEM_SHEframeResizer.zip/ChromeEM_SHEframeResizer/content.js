// Function to set the height of the specific textarea
function setTextareaHeight() {
    const textarea = document.getElementById('txtManuscriptNotes');
    if (textarea) {
        textarea.style.height = '400px'; //The number sets the height in pixels
    }
}

// Run when the page loads
setTextareaHeight();